# Handoff: Campus Plan Redesign (Coordination + Minutes)

## Overview

Redesign of the **Campus Plan** view in ATI Analysis (`Fontaineconsult/ATI_Analysis`, branch off `master`). The current CampusPlanContainer is a stack of accordion cards; this redesign turns it into an operational dashboard for campus accessibility coordinators managing ATI coordination.

Two views under one page, toggled by a segmented control:

1. **Coordination** — plan profile band (Executive Summary / Executive Sponsors / President's Report) + master–detail: unified indicator list (left) → indicator detail (right) with progress updates, companion plans, group leads, and queries.
2. **Minutes** — its own master–detail: meeting archive grouped by month (left) → full meeting record (right) with agenda, decisions, action items, attachments, notes, and cross-linked queries.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, NOT production code to copy directly. The task is to **recreate these designs in the ATI_Analysis frontend** (React + Chakra UI, `app/frontend/src`) using its established patterns: Chakra components, the existing `palette.js` / `sfsuTheme.js` tokens, and the config-driven panel patterns used elsewhere in `dashboard_components`.

- `Campus Plan HiFi.dc.html` — the hi-fi interactive prototype (authoritative for visuals + behavior). Open in a browser; the design is inside the `<x-dc>` template and the `Component` class holds all sample data and interaction logic.
- `Campus Plan Wireframes.dc.html` — earlier wireframe explorations (context only; options 3a/3b are what got approved and refined into the hi-fi).

## Fidelity

**High-fidelity.** Colors, spacing, typography, and badge treatments are deliberate and mapped to existing repo tokens (see Design Tokens). Recreate pixel-close using Chakra equivalents. Anywhere the prototype and existing repo tokens conflict, prefer the repo token — deviations are noted explicitly below.

## Placement in the Existing App

- Route: the existing Campus Plan tab in the Dashboard SubNavbar (`SubNavbar.js`, item "Campus Plan"). Keep the existing top navbar and SubNavbar exactly as they are in the app — the prototype recreates them only for context. The SubNavbar's centered layout with pipe dividers and WG dots is unchanged.
- The redesign replaces the contents of `CampusPlanContainer.js` (campus_plan_components/).
- Data: same backend resources the current container already loads — campus plan record, prioritized indicators, status updates, companion plans, working groups/leads, sponsors, queries, meeting minutes. New UI is a re-arrangement; net-new data needs are called out in **State Management**.

## Screens / Views

### Shared: Page header + profile band (both tabs)

Rendered above both views, in a `max-width: 1320px` centered container (`padding: 24px 24px 48px`):

- **Page title row**: "Campus Plan" (24px/700, #1A202C), subtitle "San Francisco State · 2025–2026 · `2025-2026-sfsu`" (13px, #718096; plan key in monospace #A0AEC0, no-wrap). Right side: segmented control (Chakra Tabs or custom): track #DFE3ED, radius 8px, padding 3px; active segment white bg, #354A7A 600, shadow `0 1px 2px rgba(0,0,0,.08)`; inactive #4A5568. Segments: **Coordination**, **Minutes**.
- **Profile band** — 3 cards in one row (`flex: 2 / 1 / 1`, gap 16px), all cards: white, 1px #E2E8F0 border, radius 8px, shadow `0 1px 2px rgba(0,0,0,.05)`, padding 20px:
  1. **Executive Summary** — section heading (12px/700 uppercase #354A7A, letter-spacing .05em) + "Edit" outline button (24px tall). Body 14px #2D3748, line-height 1.55. Editable via existing plan-editing flow.
  2. **Executive Sponsors** — heading + "Manage" outline button. Each sponsor: 26px round avatar (bg #E4E9F4, initials #354A7A 10px/700) + name (14px/500 #1A202C) on one row, **title on its own line under the name** (12px #718096, padded left 36px to align under name). Sponsors stack vertically — never side by side.
  3. **President's Report** — heading; if missing: alert box (bg #FFF5F5, 1px #FEB2B2, radius 6px, text #C53030 13px) "Not uploaded for 2025–2026." + "Upload report" outline button (30px). If uploaded: filename link + uploaded date (not in prototype; follow attachment row pattern from Minutes).

### View 1: Coordination

Two-column master–detail below the profile band: left column `flex:1, max-width:400px`, right `flex:2`, gap 16px, both top-aligned.

**Left — indicator list** (one card, padding 14px 16px):
- Search input (Chakra Input, 1px #E2E8F0, radius 6px, 13px).
- Filter pill row (wrap, gap 6px): `All 9`, `At risk 2`, `No plan 1`, `Stale 3` — pill: 1px #CBD5E0, radius full, 12px/500 #4A5568; active: bg #354A7A, white text. Counts are live. "At risk" = trajectory at_risk|failing; "No plan" = zero companion plans; "Stale" = last update age > 30d (make threshold a constant).
- Indicators grouped by working group. Group label: 10.5px/700 uppercase #718096 with 8px WG dot (Web #4966A4, Instructional Materials #635098, Procurement #DB5850).
- Row: indicator key (11px mono #718096, min-width 52px) + name (13px #1A202C, single-line ellipsis) + age chip right-aligned ("6d" 12px #718096; **stale rows: #C53030 700**). Selected row: 3px left border #4966A4, bg #F4F6FB, radius 0 6px 6px 0. Hover: bg #F7FAFC. Rows filter live; groups with no matches disappear.

**Right — indicator detail** (stack of cards, gap 12px):
1. **Header card** (padding 20px): key (15px mono/700 #2D3748) + WG badge (10px/700 uppercase; Web bg #E4E9F4 text #354A7A, IM bg #E7E2F1 text #4A3C72, Procurement bg #F9E0DE text #A33C36). Right-aligned actions: "Log update" (solid #4966A4 white, 30px, radius 6px), "Attach plan" (outline #4966A4), "Evidence" (ghost #4966A4). Below: indicator name 16px/500. Below: "MATURITY" microlabel (10px/700 uppercase #718096) + maturity pills `prev → curr` + trajectory badge.
   - Maturity pill: 12px/500, 2px left border, radius 2px, padding 1px 6px. Ramp: Not Started #E53E3E on #FDECEC; Initiated #ED8936 on #FDF1E5 text #C05621; Defined #ECC94B on #FBF6E0 text #8A6D0E; Established #41b441 on #EAF7EA text #2E7D2E; Managed #246f24 on #E5F0E5; Optimizing #157744 on #E2F1EA.
   - Trajectory badge: 12px/700, radius 2px, padding 1px 6px, Chakra subtle-badge colors: Improving green (#C6F6D5/#22543D), On Track blue (#BEE3F8/#2A4365), Stagnant yellow (#FEFCBF/#744210), At Risk orange (#FEEBC8/#7B341E), Failing red (#FED7D7/#822727).
2. **Progress Updates (N)** card (padding 14px 16px): rows (baseline-aligned, 1px #EDF2F7 bottom border): date (11px mono #718096) + trajectory badge + quoted note (13px #2D3748, lh 1.5, flex 1) + author (12px #718096, right). Inline composer at bottom: text input (flex 1) + "Trajectory ▾" select + "Log" solid button — logging happens in place, no modal.
3. **Companion Plans (N)** card: heading + "+ Attach plan" ghost. Rows: plan name (14px) + status badge (10px uppercase: In Progress blue, Completed green, Not Started gray #EDF2F7/#2D3748, On Hold orange, Abandoned red). **Zero plans → red alert box: "No plans attached yet — this indicator has no active work behind it."**
4. **Bottom split row** — two cards side by side (flex 1 each, gap 12px):
   - **Group Leads**: heading + "Manage" outline. Each lead: avatar + name row, **title on its own line beneath** (same stacked pattern as sponsors).
   - **Queries (N)**: heading + "+ New" outline. Status summary badges (e.g. "1 open" orange, "1 in progress" blue, "1 settled" green). Query cards: 1px #E2E8F0, **3px left border #6C83B8 (settled: #48BB78)**, radius 6px, padding 7px 10px, margin-top 8px — question text (13px, lh 1.45) + row of category badge, status badge, meta ("A. Reyes · 04-22 · 1 YSE", 11px #718096 no-wrap). Category badges (10px/700 uppercase): Policy Decision #E7E2F1/#3C3260, Resource Request #E4E9F4/#22304F, Technical Clarification #C4F1F9/#086F83, Information Gap #EDF2F7/#2D3748. Queries shown are the selected indicator's working group's queries.

### View 2: Minutes

Same master–detail geometry as Coordination.

**Left — meeting archive** (one card): heading "Meetings (N)" + "+ Add minutes" solid button (24px). Search input. Filter pills: All / Web / IM / Pro with live counts. Meetings **grouped by month** (label e.g. "May 2026"). Row: WG dot (joint meetings #718096) + title (13px, ellipsis) + date "05-20" (11px mono) + attachment count chip ("2 att", empty when 0). Same selected/hover treatment as indicator list.

**Right — meeting record** (stack, gap 12px):
1. **Header card**: title (16px/500) + "Edit" outline + "Delete" ghost red (#C53030). Meta row: date (12px mono) · "recorded by J. Whitfield" · WG dot + group name.
2. **Minutes card** — three subsections, headed 14px/700 #1A202C ("Agenda", "Decisions", "Action Items"):
   - Agenda & Decisions: plain bullet lines, 13.5px #2D3748.
   - **Action Items**: rows with 15px checkbox (checked: bg/border #38A169, white ✓; unchecked 2px #CBD5E0) + text (13px; done: line-through #718096) + 22px owner avatar + due label right ("due 06-10 · overdue" → #C53030 700; "done 05-24" / "due 07-15" → #718096).
3. **Bottom split row** — **Attachments (N)** (rows: kind tag "DOC"/"URL" 9.5px/700 bg #EDF2F7 + link 13px #4966A4; empty: italic gray "Nothing attached yet.") | **Notes (N)** (note boxes bg #F7FAFC radius 6px, quoted text 13px + date 11px; empty state).
4. **Raised in this Meeting (N)** card: heading + "View in Coordination →" ghost button that **switches to the Coordination tab**. Query cards identical to Coordination's. Empty: "No queries raised in this meeting."

## Interactions & Behavior

- Coordination/Minutes toggle preserves each view's selection state. Deep-link support (`?view=minutes&id=…`) recommended.
- Indicator/meeting list rows: click selects and repaints right panel. Hover #F7FAFC.
- Filter pills and search filter lists live; counts reflect the dataset.
- Progress-update composer logs inline (POST + optimistic append).
- "View in Coordination →" switches tabs.
- Buttons: hover per Chakra defaults for solid/outline/ghost variants.
- No accordions anywhere — everything readable without expand/collapse.

## State Management

- Page state: `view` (coord|minutes), `selectedIndicatorKey`, `selectedMinutesId`, `indicatorFilter`, `minutesFilter`, search strings.
- Derived: stale = daysSince(lastUpdate) > 30; risk = trajectory ∈ {at_risk, failing}; counts per filter.
- Data: current Campus Plan endpoints suffice for indicators, updates, plans, sponsors, leads, minutes, queries. **Net-new needs**: (1) action items as structured data on minutes (text, owner, done, due date) — currently minutes are prose; (2) query↔meeting linkage for "Raised in this Meeting"; (3) attachment kind (DOC/URL). If backend changes are out of scope, phase 1 can render minutes prose + omit those two cards.

## Design Tokens

From the repo (`palette.js` / `sfsuTheme.js` / Chakra defaults) — use existing token names wherever they exist:

- Brand blues: #4966A4 (primary / Web WG), #354A7A (headings/active), #2A3A62 (navbar), #223153 (navbar border)
- WG accents: Web #4966A4 · Instructional Materials #635098 · Procurement #DB5850 · joint/neutral #718096
- Neutrals (Chakra gray): #1A202C, #2D3748, #4A5568, #718096, #A0AEC0, #CBD5E0, #E2E8F0, #EDF2F7, #F7FAFC; page bg #eceef2; selected-row tint #F4F6FB
- Maturity ramp + trajectory/status badge pairs: exact hexes in the sections above
- Type: Roboto (existing app font); 24 title / 16 detail-title / 14 body / 13 secondary / 12 badges+headings / 11 mono meta / 10–10.5 microlabels; mono = ui-monospace stack
- Radii: cards+alerts+segmented track 8px (thumb 6px), buttons/inputs/query cards 6px, checkboxes 3px, badges+maturity pills 2px, filter pills full
- Shadows: card `0 1px 2px rgba(0,0,0,.05)`; segmented thumb `0 1px 2px rgba(0,0,0,.08)`
- Spacing: card padding 20px (header cards) / 14–16px (list cards); column gap 16px; card stack gap 12px; page container 1320px max, 24px side padding

## Assets

- `sfbrn-logo-light.svg` — already in repo at `app/frontend/src/src/assets/img/`. No new assets required. Avatars are initials-based (Chakra Avatar).

## Files

- `Campus Plan HiFi.dc.html` — authoritative hi-fi prototype (both views, working interactions, all sample data in the `Component` class)
- `Campus Plan Wireframes.dc.html` — wireframe exploration history (turns 1–3; approved directions 3a/3b)
- `sfbrn-logo-light.svg` — copy of the repo logo used by the prototype

## Sample Data Note

All names, indicator keys, updates, and meetings in the prototype are **realistic fiction** for design purposes. Do not seed the database from them.
